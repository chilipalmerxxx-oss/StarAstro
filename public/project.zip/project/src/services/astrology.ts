import * as Astronomy from 'astronomy-engine';

export interface BirthData {
  date: Date;
  latitude: number;
  longitude: number;
}

export interface PlanetPosition {
  longitude: number;
  latitude: number;
  distance: number;
  sign: string;
  signDegree: number;
  house: number;
}

export interface House {
  cusp: number;
  sign: string;
  signDegree: number;
}

export interface Aspect {
  planet1: string;
  planet2: string;
  type: string;
  angle: number;
  orb: number;
}

const ZODIAC_SIGNS = [
  'Bélier', 'Taureau', 'Gémeaux', 'Cancer',
  'Lion', 'Vierge', 'Balance', 'Scorpion',
  'Sagittaire', 'Capricorne', 'Verseau', 'Poissons'
];

const PLANETS = [
  { key: 'sun', name: 'Soleil', body: Astronomy.Body.Sun },
  { key: 'moon', name: 'Lune', body: Astronomy.Body.Moon },
  { key: 'mercury', name: 'Mercure', body: Astronomy.Body.Mercury },
  { key: 'venus', name: 'Vénus', body: Astronomy.Body.Venus },
  { key: 'mars', name: 'Mars', body: Astronomy.Body.Mars },
  { key: 'jupiter', name: 'Jupiter', body: Astronomy.Body.Jupiter },
  { key: 'saturn', name: 'Saturne', body: Astronomy.Body.Saturn },
  { key: 'uranus', name: 'Uranus', body: Astronomy.Body.Uranus },
  { key: 'neptune', name: 'Neptune', body: Astronomy.Body.Neptune },
  { key: 'pluto', name: 'Pluton', body: Astronomy.Body.Pluto },
];

const ASPECT_TYPES = [
  { name: 'Conjonction', angle: 0, orb: 8 },
  { name: 'Sextile', angle: 60, orb: 6 },
  { name: 'Carré', angle: 90, orb: 8 },
  { name: 'Trigone', angle: 120, orb: 8 },
  { name: 'Opposition', angle: 180, orb: 8 },
];

function getZodiacSign(longitude: number): { sign: string; degree: number } {
  const normalizedLon = ((longitude % 360) + 360) % 360;
  const signIndex = Math.floor(normalizedLon / 30);
  const degree = normalizedLon % 30;
  return {
    sign: ZODIAC_SIGNS[signIndex],
    degree: degree,
  };
}

function eclipticToZodiac(ecliptic: Astronomy.Ecliptic): number {
  return ecliptic.elon;
}

export function calculatePlanetPositions(birthData: BirthData): Record<string, PlanetPosition> {
  const positions: Record<string, PlanetPosition> = {};

  for (const planet of PLANETS) {
    const geoVector = Astronomy.GeoVector(planet.body, birthData.date, false);
    const ecliptic = Astronomy.Ecliptic(geoVector);

    const longitude = eclipticToZodiac(ecliptic);
    const { sign, degree } = getZodiacSign(longitude);

    positions[planet.key] = {
      longitude,
      latitude: ecliptic.elat,
      distance: 0,
      sign,
      signDegree: degree,
      house: 0,
    };
  }

  return positions;
}

function calculateAscendant(birthData: BirthData): number {
  const time = Astronomy.MakeTime(birthData.date);

  const jd = time.ut + 2451545.0;
  const T = (jd - 2451545.0) / 36525.0;

  const gmst0 = 280.46061837 + 360.98564736629 * (jd - 2451545.0) +
                0.000387933 * T * T - T * T * T / 38710000.0;

  let gmst = gmst0 % 360;
  if (gmst < 0) gmst += 360;

  let lst = gmst + birthData.longitude;
  if (lst < 0) lst += 360;
  if (lst >= 360) lst -= 360;

  const obliquity = 23.4392911 - 0.0130042 * T - 0.00000016 * T * T + 0.000000504 * T * T * T;

  const lstRad = lst * Math.PI / 180;
  const latRad = birthData.latitude * Math.PI / 180;
  const oblRad = obliquity * Math.PI / 180;

  const y = -Math.cos(lstRad);
  const x = Math.sin(lstRad) * Math.cos(oblRad) + Math.tan(latRad) * Math.sin(oblRad);

  let ascendant = Math.atan2(y, x) * 180 / Math.PI;

  if (ascendant < 0) ascendant += 360;

  ascendant = (ascendant + 180) % 360;

  return ascendant;
}

export function calculateHouses(birthData: BirthData, planetPositions: Record<string, PlanetPosition>): House[] {
  const houses: House[] = [];
  const ascendantLon = calculateAscendant(birthData);

  for (let i = 0; i < 12; i++) {
    const cuspLon = (ascendantLon + i * 30) % 360;
    const { sign, degree } = getZodiacSign(cuspLon);
    houses.push({
      cusp: cuspLon,
      sign,
      signDegree: degree,
    });
  }

  Object.keys(planetPositions).forEach(planetKey => {
    const planet = planetPositions[planetKey];
    for (let i = 0; i < 12; i++) {
      const nextHouse = (i + 1) % 12;
      const currentCusp = houses[i].cusp;
      const nextCusp = houses[nextHouse].cusp;

      if (nextCusp > currentCusp) {
        if (planet.longitude >= currentCusp && planet.longitude < nextCusp) {
          planet.house = i + 1;
          break;
        }
      } else {
        if (planet.longitude >= currentCusp || planet.longitude < nextCusp) {
          planet.house = i + 1;
          break;
        }
      }
    }
  });

  return houses;
}

export function calculateAspects(planetPositions: Record<string, PlanetPosition>, ascendantLongitude?: number): Aspect[] {
  const aspects: Aspect[] = [];
  const positions: Record<string, number> = {};

  Object.keys(planetPositions).forEach(key => {
    positions[key] = planetPositions[key].longitude;
  });

  if (ascendantLongitude !== undefined) {
    positions['ascendant'] = ascendantLongitude;
  }

  const keys = Object.keys(positions);

  for (let i = 0; i < keys.length; i++) {
    for (let j = i + 1; j < keys.length; j++) {
      const planet1 = keys[i];
      const planet2 = keys[j];
      const lon1 = positions[planet1];
      const lon2 = positions[planet2];

      let angle = Math.abs(lon1 - lon2);
      if (angle > 180) angle = 360 - angle;

      for (const aspectType of ASPECT_TYPES) {
        const orb = Math.abs(angle - aspectType.angle);
        if (orb <= aspectType.orb) {
          aspects.push({
            planet1,
            planet2,
            type: aspectType.name,
            angle: aspectType.angle,
            orb,
          });
        }
      }
    }
  }

  return aspects;
}

export function calculateBirthChart(birthData: BirthData) {
  const planetPositions = calculatePlanetPositions(birthData);
  const houses = calculateHouses(birthData, planetPositions);
  const aspects = calculateAspects(planetPositions, houses[0]?.cusp);

  return {
    planetPositions,
    houses,
    aspects,
  };
}
