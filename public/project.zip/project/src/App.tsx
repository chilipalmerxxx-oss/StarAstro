import { useState } from 'react';
import { Sparkles, ArrowLeft, History } from 'lucide-react';
import LandingPage from './components/LandingPage';
import BirthDataForm from './components/BirthDataForm';
import NatalChart from './components/NatalChart';
import Interpretation from './components/Interpretation';
import AspectsList from './components/AspectsList';
import SavedCharts from './components/SavedCharts';
import { calculateBirthChart } from './services/astrology';
import { Supabase } from './lib/supabase';
import { getSessionId } from './lib/session';

interface ChartData {
  name: string;
  birthDate: Date;
  birthPlace: string;
  planetPositions: Record<string, any>;
  houses: any[];
  aspects: any[];
}

function App() {
  const [showLanding, setShowLanding] = useState(true);
  const [chartData, setChartData] = useState<ChartData | null>(null);
  const [loading, setLoading] = useState(false);
  const [showSavedCharts, setShowSavedCharts] = useState(false);

  const handleSubmit = async (data: {
    name: string;
    date: string;
    time: string;
    place: string;
    latitude: number;
    longitude: number;
    timezoneOffset: number;
  }) => {
    setLoading(true);

    try {
      const birthDateTime = new Date(`${data.date}T${data.time}`);

      const chart = calculateBirthChart({
        date: birthDateTime,
        latitude: data.latitude,
        longitude: data.longitude,
      });

      const { data: { user } } = await Supabase.auth.getUser();

      const { error } = await Supabase.from('birth_charts').insert({
        name: data.name,
        birth_date: birthDateTime.toISOString(),
        birth_place: data.place,
        latitude: data.latitude,
        longitude: data.longitude,
        timezone_offset: data.timezoneOffset,
        planet_positions: chart.planetPositions,
        houses: chart.houses,
        aspects: chart.aspects,
        user_id: user?.id || null,
        session_id: user ? null : getSessionId(),
      });

      if (error) {
        console.error('Error saving to database:', error);
      }

      setChartData({
        name: data.name,
        birthDate: birthDateTime,
        birthPlace: data.place,
        planetPositions: chart.planetPositions,
        houses: chart.houses,
        aspects: chart.aspects,
      });
    } catch (error) {
      console.error('Error calculating chart:', error);
      alert('Une erreur est survenue lors du calcul du thème astral.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setChartData(null);
  };

  const handleGetStarted = () => {
    setShowLanding(false);
  };

  const handleBackToHome = () => {
    setShowLanding(true);
    setChartData(null);
  };

  const handleLoadChart = (chart: ChartData) => {
    setChartData(chart);
  };

  if (showLanding) {
    return <LandingPage onGetStarted={handleGetStarted} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-blue-50 to-cyan-50">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="flex items-center justify-between mb-6">
            <button
              onClick={handleBackToHome}
              className="inline-flex items-center gap-2 text-slate-600 hover:text-slate-800 transition"
            >
              <ArrowLeft className="w-5 h-5" />
              Retour à l'accueil
            </button>
            <button
              onClick={() => setShowSavedCharts(true)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-800 transition shadow-md"
            >
              <History className="w-5 h-5" />
              Historique
            </button>
          </div>
          <div className="flex items-center justify-center gap-3 mb-4">
            <Sparkles className="w-10 h-10 text-cyan-600" />
            <h1 className="text-5xl font-bold text-slate-800">AstroThème</h1>
          </div>
          <p className="text-lg text-slate-600">
            Découvrez votre thème astral basé sur des calculs astronomiques précis
          </p>
        </div>

        <div className="flex flex-col items-center gap-8">
          {!chartData ? (
            <BirthDataForm onSubmit={handleSubmit} loading={loading} />
          ) : (
            <>
              <button
                onClick={handleReset}
                className="bg-slate-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-slate-700 transition"
              >
                Nouveau thème
              </button>

              <NatalChart
                name={chartData.name}
                planetPositions={chartData.planetPositions}
                houses={chartData.houses}
                aspects={chartData.aspects}
              />

              <Interpretation
                name={chartData.name}
                planetPositions={chartData.planetPositions}
                aspects={chartData.aspects}
              />

              <AspectsList aspects={chartData.aspects} />
            </>
          )}
        </div>

        <footer className="text-center mt-16 text-sm text-slate-500">
          <p>Calculs astronomiques réalisés avec astronomy-engine</p>
          <p className="mt-1">Les positions planétaires sont calculées avec précision scientifique</p>
        </footer>
      </div>

      {showSavedCharts && (
        <SavedCharts
          onLoadChart={handleLoadChart}
          onClose={() => setShowSavedCharts(false)}
        />
      )}
    </div>
  );
}

export default App;
