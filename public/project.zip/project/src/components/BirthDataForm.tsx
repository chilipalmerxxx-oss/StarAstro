import React, { useState } from 'react';
import { MapPin, Calendar, Clock } from 'lucide-react';

interface BirthDataFormProps {
  onSubmit: (data: {
    name: string;
    date: string;
    time: string;
    place: string;
    latitude: number;
    longitude: number;
    timezoneOffset: number;
  }) => void;
  loading?: boolean;
}

const CITIES = [
  { name: 'Paris', lat: 48.8566, lon: 2.3522, tz: 1 },
  { name: 'Lyon', lat: 45.7640, lon: 4.8357, tz: 1 },
  { name: 'Marseille', lat: 43.2965, lon: 5.3698, tz: 1 },
  { name: 'Toulouse', lat: 43.6047, lon: 1.4442, tz: 1 },
  { name: 'Bordeaux', lat: 44.8378, lon: -0.5792, tz: 1 },
  { name: 'Lille', lat: 50.6292, lon: 3.0573, tz: 1 },
  { name: 'Nice', lat: 43.7102, lon: 7.2620, tz: 1 },
  { name: 'Nantes', lat: 47.2184, lon: -1.5536, tz: 1 },
  { name: 'Strasbourg', lat: 48.5734, lon: 7.7521, tz: 1 },
  { name: 'Montpellier', lat: 43.6108, lon: 3.8767, tz: 1 },
  { name: 'Bruxelles', lat: 50.8503, lon: 4.3517, tz: 1 },
  { name: 'Genève', lat: 46.2044, lon: 6.1432, tz: 1 },
  { name: 'Londres', lat: 51.5074, lon: -0.1278, tz: 0 },
  { name: 'New York', lat: 40.7128, lon: -74.0060, tz: -5 },
  { name: 'Los Angeles', lat: 34.0522, lon: -118.2437, tz: -8 },
];

export default function BirthDataForm({ onSubmit, loading = false }: BirthDataFormProps) {
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('12:00');
  const [selectedCity, setSelectedCity] = useState(CITIES[0].name);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const city = CITIES.find(c => c.name === selectedCity) || CITIES[0];

    onSubmit({
      name,
      date,
      time,
      place: selectedCity,
      latitude: city.lat,
      longitude: city.lon,
      timezoneOffset: city.tz,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl p-8 max-w-2xl w-full">
      <h2 className="text-3xl font-bold text-slate-800 mb-6">Votre Thème Astral</h2>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Nom
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
            placeholder="Entrez votre nom"
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              <Calendar className="inline w-4 h-4 mr-1" />
              Date de naissance
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              <Clock className="inline w-4 h-4 mr-1" />
              Heure de naissance
            </label>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            <MapPin className="inline w-4 h-4 mr-1" />
            Lieu de naissance
          </label>
          <select
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition bg-white"
            required
          >
            {CITIES.map(city => (
              <option key={city.name} value={city.name}>
                {city.name}
              </option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-4 rounded-lg font-semibold hover:from-blue-700 hover:to-cyan-700 transition transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          {loading ? 'Calcul en cours...' : 'Générer mon thème astral'}
        </button>
      </div>
    </form>
  );
}
