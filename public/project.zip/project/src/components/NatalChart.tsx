import { useState } from 'react';
import DetailModal from './DetailModal';

interface NatalChartProps {
  name: string;
  planetPositions: Record<string, any>;
  houses: any[];
  aspects: any[];
}

const zodiacSigns = [
  { symbol: '♈', name: 'Bélier', emoji: '🐏' },
  { symbol: '♉', name: 'Taureau', emoji: '🐂' },
  { symbol: '♊', name: 'Gémeaux', emoji: '👯' },
  { symbol: '♋', name: 'Cancer', emoji: '🦀' },
  { symbol: '♌', name: 'Lion', emoji: '🦁' },
  { symbol: '♍', name: 'Vierge', emoji: '🌸' },
  { symbol: '♎', name: 'Balance', emoji: '⚖️' },
  { symbol: '♏', name: 'Scorpion', emoji: '🦂' },
  { symbol: '♐', name: 'Sagittaire', emoji: '🏹' },
  { symbol: '♑', name: 'Capricorne', emoji: '🐐' },
  { symbol: '♒', name: 'Verseau', emoji: '🏺' },
  { symbol: '♓', name: 'Poissons', emoji: '🐟' },
];

const planetGlyphs: Record<string, string> = {
  sun: '☉',
  moon: '☽',
  mercury: '☿',
  venus: '♀',
  mars: '♂',
  jupiter: '♃',
  saturn: '♄',
  uranus: '♅',
  neptune: '♆',
  pluto: '♇',
  ascendant: 'ASC',
};

const planetNames: Record<string, string> = {
  sun: 'Soleil',
  moon: 'Lune',
  mercury: 'Mercure',
  venus: 'Vénus',
  mars: 'Mars',
  jupiter: 'Jupiter',
  saturn: 'Saturne',
  uranus: 'Uranus',
  neptune: 'Neptune',
  pluto: 'Pluton',
  ascendant: 'Ascendant',
};

const planetColors: Record<string, string> = {
  sun: '#F59E0B',
  moon: '#9CA3AF',
  mercury: '#06B6D4',
  venus: '#EC4899',
  mars: '#EF4444',
  jupiter: '#10B981',
  saturn: '#8B7355',
  uranus: '#3B82F6',
  neptune: '#8B5CF6',
  pluto: '#A855F7',
  ascendant: '#1e293b',
};

export default function NatalChart({
  name,
  planetPositions,
  houses,
  aspects,
}: NatalChartProps) {
  const [selectedPlanet, setSelectedPlanet] = useState<string | null>(null);
  const [hoveredPlanet, setHoveredPlanet] = useState<string | null>(null);
  const [hoveredAspect, setHoveredAspect] = useState<number | null>(null);
  const [selectedAspect, setSelectedAspect] = useState<number | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const size = 600;
  const center = size / 2;
  const radiusOuter = 195;
  const radiusHouses = 135;
  const radiusInner = 105;
  const radiusPlanets = 245;

  const getXY = (angleDeg: number, radius: number) => {
    const rad = ((180 - angleDeg) * Math.PI) / 180;
    return {
      x: center + radius * Math.cos(rad),
      y: center + radius * Math.sin(rad),
    };
  };

  const detectConjunctions = () => {
    const planetsArray = Object.entries(planetPositions).map(([key, pos]) => ({
      key,
      longitude: pos.longitude,
    }));

    const offsets: Record<string, number> = {};
    const threshold = 2;

    planetsArray.sort((a, b) => a.longitude - b.longitude);

    planetsArray.forEach((planet, i) => {
      let offset = 0;
      for (let j = 0; j < i; j++) {
        const other = planetsArray[j];
        let diff = Math.abs(planet.longitude - other.longitude);
        if (diff > 180) diff = 360 - diff;

        if (diff < threshold) {
          offset = (offsets[other.key] || 0) + 1;
        }
      }
      offsets[planet.key] = offset;
    });

    return offsets;
  };

  const conjunctionOffsets = detectConjunctions();

  const getAspectColor = (type: string): string => {
    const typeMap: Record<string, string> = {
      Conjonction: '#10B981',
      Sextile: '#3B82F6',
      Carré: '#EF4444',
      Trigone: '#10B981',
      Opposition: '#EF4444',
    };
    return typeMap[type] || '#9E9E9E';
  };

  const getAspectOpacity = (type: string): number => {
    const typeMap: Record<string, number> = {
      Conjonction: 0.6,
      Sextile: 0.5,
      Carré: 0.7,
      Trigone: 0.6,
      Opposition: 0.7,
    };
    return typeMap[type] || 0.4;
  };

  const getAspectStrokeWidth = (type: string): number => {
    const typeMap: Record<string, number> = {
      Conjonction: 2.5,
      Carré: 2.5,
      Opposition: 2.5,
      Trigone: 2,
      Sextile: 2,
    };
    return typeMap[type] || 1.5;
  };

  const getCardinalPoints = () => {
    const points = [
      { label: 'ASC', angle: houses[0]?.cusp || 0 },
      { label: 'DSC', angle: houses[6]?.cusp || 180 },
      { label: 'MC', angle: houses[9]?.cusp || 270 },
      { label: 'FC', angle: houses[3]?.cusp || 90 },
    ];
    return points.map(point => {
      const signIndex = Math.floor(point.angle / 30);
      const signDegree = point.angle % 30;
      const sign = zodiacSigns[signIndex]?.name || '';
      return { ...point, sign, signDegree };
    });
  };

  const cardinalPoints = getCardinalPoints();

  return (
    <div className={`flex flex-col items-center gap-4 md:gap-6 bg-gradient-to-br from-slate-50 to-slate-100 rounded-3xl shadow-2xl p-4 md:p-8 ${isFullscreen ? 'fixed inset-0 z-50 rounded-none overflow-auto' : ''}`}>
      <div className="flex items-center justify-end w-full mb-2 md:mb-4">
        <button
          onClick={() => setIsFullscreen(!isFullscreen)}
          className="px-3 md:px-5 py-2 md:py-2.5 rounded-xl text-sm md:text-base font-semibold transition-all shadow-md bg-slate-700 text-white hover:bg-slate-800"
        >
          {isFullscreen ? 'Quitter' : 'Plein écran'}
        </button>
      </div>

      <div className="relative w-full flex justify-center px-4">
        <div className="w-full max-w-[600px] flex justify-center">
          <svg viewBox="0 0 600 600" className="drop-shadow-2xl w-full h-auto max-w-full">
          <defs>
            <radialGradient id="centerGradient" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#FEFCE8" />
              <stop offset="100%" stopColor="#FEF3C7" />
            </radialGradient>

            <linearGradient id="zodiacGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e293b" />
              <stop offset="50%" stopColor="#334155" />
              <stop offset="100%" stopColor="#1e293b" />
            </linearGradient>

            <linearGradient id="houseGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#cbd5e1" />
              <stop offset="100%" stopColor="#94a3b8" />
            </linearGradient>

            <filter id="shadow">
              <feDropShadow dx="0" dy="2" stdDeviation="4" floodOpacity="0.3" />
            </filter>

            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          <circle
            cx={center}
            cy={center}
            r={radiusOuter}
            fill="url(#zodiacGradient)"
            stroke="#0f172a"
            strokeWidth="4"
            filter="url(#shadow)"
          />

          {zodiacSigns.map((sign, i) => {
            const angle = i * 30;

            return (
              <g key={`zodiac-${i}`}>
                <line
                  x1={getXY(angle, radiusHouses).x}
                  y1={getXY(angle, radiusHouses).y}
                  x2={getXY(angle, radiusOuter).x}
                  y2={getXY(angle, radiusOuter).y}
                  stroke="#D4AF37"
                  strokeWidth="2.5"
                />

                <text
                  x={getXY(angle + 15, (radiusHouses + radiusOuter) / 2).x}
                  y={getXY(angle + 15, (radiusHouses + radiusOuter) / 2).y}
                  fontSize="26"
                  textAnchor="middle"
                  dominantBaseline="middle"
                  style={{
                    filter: 'drop-shadow(0 0 3px rgba(255,255,255,0.4)) drop-shadow(0 1px 2px rgba(0,0,0,0.3))'
                  }}
                >
                  {sign.emoji}
                </text>
              </g>
            );
          })}

          <circle
            cx={center}
            cy={center}
            r={radiusHouses}
            fill="url(#houseGradient)"
            stroke="#475569"
            strokeWidth="3"
          />

          {houses.map((house, i) => {
            const angle = house.cusp;
            const { x: x1, y: y1 } = getXY(angle, radiusInner);
            const { x: x2, y: y2 } = getXY(angle, radiusHouses);

            const isCardinal = i === 0 || i === 3 || i === 6 || i === 9;

            return (
              <line
                key={`house-${i}`}
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke={isCardinal ? '#1e293b' : '#475569'}
                strokeWidth={isCardinal ? '3' : '1.5'}
              />
            );
          })}

          {houses.map((house, i) => {
            const nextHouse = houses[(i + 1) % 12];
            let midAngle = (house.cusp + nextHouse.cusp) / 2;
            if (nextHouse.cusp < house.cusp) {
              midAngle = ((house.cusp + nextHouse.cusp + 360) / 2) % 360;
            }
            const { x, y } = getXY(midAngle, (radiusHouses + radiusInner) / 2);
            return (
              <text
                key={`house-num-${i}`}
                x={x}
                y={y}
                fontSize="22"
                fontWeight="800"
                textAnchor="middle"
                dominantBaseline="middle"
                fill="#1e293b"
                style={{
                  fontFamily: 'Times New Roman, Times, serif',
                  letterSpacing: '0.5px'
                }}
              >
                {i + 1}
              </text>
            );
          })}

          <circle
            cx={center}
            cy={center}
            r={radiusInner}
            fill="url(#centerGradient)"
            stroke="#334155"
            strokeWidth="3"
            filter="url(#shadow)"
          />

          {aspects.map((asp, i) => {
              let lon1, lon2;

              if (asp.planet1 === 'ascendant') {
                lon1 = houses[0]?.cusp || 0;
              } else {
                const p1 = planetPositions[asp.planet1];
                if (!p1) return null;
                lon1 = p1.longitude;
              }

              if (asp.planet2 === 'ascendant') {
                lon2 = houses[0]?.cusp || 0;
              } else {
                const p2 = planetPositions[asp.planet2];
                if (!p2) return null;
                lon2 = p2.longitude;
              }

              const a = getXY(lon1, radiusInner);
              const b = getXY(lon2, radiusInner);

              const isHovered = hoveredAspect === i;
              const isSelected = selectedAspect === i;
              const isHighlighted = isHovered || isSelected;

              return (
                <line
                  key={`aspect-${i}`}
                  x1={a.x}
                  y1={a.y}
                  x2={b.x}
                  y2={b.y}
                  stroke={getAspectColor(asp.type)}
                  strokeWidth={isHighlighted ? getAspectStrokeWidth(asp.type) + 2 : getAspectStrokeWidth(asp.type)}
                  opacity={isHighlighted ? 0.9 : getAspectOpacity(asp.type)}
                  strokeLinecap="round"
                  style={{
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    filter: isHighlighted ? 'drop-shadow(0 0 4px currentColor)' : 'none'
                  }}
                  onMouseEnter={() => setHoveredAspect(i)}
                  onMouseLeave={() => setHoveredAspect(null)}
                  onClick={() => setSelectedAspect(selectedAspect === i ? null : i)}
                />
              );
            })}

          {Object.entries(planetPositions).map(([key, pos]) => {
            const offset = conjunctionOffsets[key] || 0;
            const adjustedRadius = radiusPlanets + (offset * 40);

            const { x, y } = getXY(pos.longitude, adjustedRadius);
            const { x: lineX, y: lineY } = getXY(pos.longitude, radiusOuter);

            const isHovered = hoveredPlanet === key;
            const isSelected = selectedPlanet === key;
            const isHighlighted = isHovered || isSelected;

            const angleDeg = pos.longitude;
            const angleForDegree = angleDeg % 360;
            let degreeYOffset = -32;
            let degreeXOffset = 0;

            if (angleForDegree > 45 && angleForDegree < 135) {
              degreeYOffset = -32;
            } else if (angleForDegree >= 135 && angleForDegree < 225) {
              degreeXOffset = -40;
              degreeYOffset = 0;
            } else if (angleForDegree >= 225 && angleForDegree < 315) {
              degreeYOffset = 32;
            } else {
              degreeXOffset = 40;
              degreeYOffset = 0;
            }

            return (
              <g key={`planet-${key}`}>
                <line
                  x1={lineX}
                  y1={lineY}
                  x2={x}
                  y2={y}
                  stroke="#94a3b8"
                  strokeWidth="2"
                  opacity="0.6"
                />

                <circle
                  cx={x}
                  cy={y}
                  r={isHighlighted ? '26' : '22'}
                  fill={planetColors[key] || '#64748b'}
                  stroke="white"
                  strokeWidth={isHighlighted ? '3.5' : '3'}
                  filter="url(#shadow)"
                  style={{
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={() => setHoveredPlanet(key)}
                  onMouseLeave={() => setHoveredPlanet(null)}
                  onClick={() => setSelectedPlanet(key)}
                />

<text
                  x={x}
                  y={y + 1}
                  fontSize={isHighlighted ? '22' : '20'}
                  fontWeight="700"
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill="white"
                  style={{
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    pointerEvents: 'none',
                  }}
                >
                  {planetGlyphs[key] || '?'}
                </text>

                <text
                  x={x + degreeXOffset}
                  y={y + degreeYOffset}
                  fontSize="12"
                  fontWeight="800"
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill="#1e293b"
                  style={{
                    textShadow: '0 0 4px white, 0 0 8px white, 0 0 12px white',
                    paintOrder: 'stroke fill'
                  }}
                >
                  {pos.signDegree.toFixed(1)}
                </text>
              </g>
            );
          })}

          {cardinalPoints.map((point, i) => {
            const distance = radiusPlanets + 60;
            const { x, y } = getXY(point.angle, distance);
            const { x: lineX, y: lineY } = getXY(point.angle, radiusOuter);
            const isAscendant = point.label === 'ASC';
            const isHovered = hoveredPlanet === 'ascendant' && isAscendant;
            const isSelected = selectedPlanet === 'ascendant' && isAscendant;
            const isHighlighted = isAscendant && (isHovered || isSelected);

            return (
              <g key={`cardinal-${i}`}>
                <line
                  x1={lineX}
                  y1={lineY}
                  x2={x}
                  y2={y}
                  stroke="#94a3b8"
                  strokeWidth="2"
                  opacity="0.6"
                />
                <circle
                  cx={x}
                  cy={y}
                  r={isHighlighted ? '28' : '26'}
                  fill="white"
                  stroke={isAscendant ? '#1e293b' : '#64748b'}
                  strokeWidth={isHighlighted ? '4' : '3.5'}
                  filter="url(#shadow)"
                  style={isAscendant ? {
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                  } : {}}
                  onMouseEnter={isAscendant ? () => setHoveredPlanet('ascendant') : undefined}
                  onMouseLeave={isAscendant ? () => setHoveredPlanet(null) : undefined}
                  onClick={isAscendant ? () => setSelectedPlanet('ascendant') : undefined}
                />
                <text
                  x={x}
                  y={y + 1}
                  fontSize={isHighlighted ? '17' : '16'}
                  fontWeight="800"
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill={isAscendant ? '#1e293b' : '#64748b'}
                  style={isAscendant ? {
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    pointerEvents: 'none',
                  } : {}}
                >
                  {point.label}
                </text>
              </g>
            );
          })}
        </svg>
        </div>

        {hoveredPlanet && (
          <div
            className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-slate-900 text-white px-5 py-3 rounded-xl shadow-2xl z-10 border border-slate-700"
            style={{ pointerEvents: 'none' }}
          >
<div className="text-base font-bold">
              {planetNames[hoveredPlanet]} {planetGlyphs[hoveredPlanet]}
            </div>
            <div className="text-sm text-slate-300 mt-1">
              {hoveredPlanet === 'ascendant'
                ? `${houses[0]?.sign} ${houses[0]?.signDegree.toFixed(2)}°`
                : `${planetPositions[hoveredPlanet].sign} ${planetPositions[hoveredPlanet].signDegree.toFixed(2)}°`
              }
            </div>
            <div className="text-sm text-slate-300">
              Maison {hoveredPlanet === 'ascendant' ? '1' : planetPositions[hoveredPlanet].house}
            </div>
          </div>
        )}

        {hoveredAspect !== null && aspects[hoveredAspect] && (
          <div
            className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-slate-900 text-white px-5 py-3 rounded-xl shadow-2xl z-10 border border-slate-700"
            style={{ pointerEvents: 'none' }}
          >
            <div className="text-base font-bold">
              {aspects[hoveredAspect].type}
            </div>
            <div className="text-sm text-slate-300 mt-1">
              {planetNames[aspects[hoveredAspect].planet1]} {planetGlyphs[aspects[hoveredAspect].planet1]} - {planetNames[aspects[hoveredAspect].planet2]} {planetGlyphs[aspects[hoveredAspect].planet2]}
            </div>
            <div className="text-sm text-slate-300">
              Orbe: {aspects[hoveredAspect].orb.toFixed(2)}°
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 md:gap-3 w-full mt-2 md:mt-4">
        <button
          key="ascendant"
          onClick={() => setSelectedPlanet('ascendant')}
          onMouseEnter={() => setHoveredPlanet('ascendant')}
          onMouseLeave={() => setHoveredPlanet(null)}
          className={`flex items-center gap-2 md:gap-3 px-3 md:px-4 py-2 md:py-3 rounded-xl transition-all shadow-md ${
            selectedPlanet === 'ascendant' || hoveredPlanet === 'ascendant'
              ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white scale-105'
              : 'bg-white text-slate-700 hover:bg-slate-50 border-2 border-slate-200'
          }`}
        >
          <div
            className="w-7 h-7 md:w-8 md:h-8 rounded-full flex items-center justify-center text-white font-bold text-xs md:text-sm shadow-md flex-shrink-0"
            style={{ backgroundColor: planetColors['ascendant'] }}
          >
            {planetGlyphs['ascendant']}
          </div>
          <div className="text-left text-xs md:text-sm min-w-0 flex-1">
            <div className={`font-bold truncate ${selectedPlanet === 'ascendant' || hoveredPlanet === 'ascendant' ? 'text-white' : 'text-slate-800'}`}>
              {planetNames['ascendant']}
            </div>
            <div className={`text-xs truncate ${selectedPlanet === 'ascendant' || hoveredPlanet === 'ascendant' ? 'text-blue-100' : 'text-slate-500'}`}>
              {houses[0]?.sign} {houses[0]?.signDegree.toFixed(1)}°
            </div>
          </div>
        </button>
        {Object.entries(planetPositions).map(([key, pos]) => (
          <button
            key={key}
            onClick={() => setSelectedPlanet(key)}
            onMouseEnter={() => setHoveredPlanet(key)}
            onMouseLeave={() => setHoveredPlanet(null)}
            className={`flex items-center gap-2 md:gap-3 px-3 md:px-4 py-2 md:py-3 rounded-xl transition-all shadow-md ${
              selectedPlanet === key || hoveredPlanet === key
                ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white scale-105'
                : 'bg-white text-slate-700 hover:bg-slate-50 border-2 border-slate-200'
            }`}
          >
            <div
              className="w-7 h-7 md:w-8 md:h-8 rounded-full flex items-center justify-center text-white font-bold text-xs md:text-sm shadow-md flex-shrink-0"
              style={{ backgroundColor: planetColors[key] }}
            >
              {planetGlyphs[key]}
            </div>
            <div className="text-left text-xs md:text-sm min-w-0 flex-1">
              <div className={`font-bold truncate ${selectedPlanet === key || hoveredPlanet === key ? 'text-white' : 'text-slate-800'}`}>
                {planetNames[key]}
              </div>
              <div className={`text-xs truncate ${selectedPlanet === key || hoveredPlanet === key ? 'text-blue-100' : 'text-slate-500'}`}>
                {pos.sign} {pos.signDegree.toFixed(1)}°
              </div>
            </div>
          </button>
        ))}
      </div>

      <div className="w-full mt-2 p-4 md:p-5 bg-white rounded-xl shadow-md border border-slate-200">
        <h3 className="text-base md:text-lg font-bold text-slate-800 mb-3">Légende des aspects</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 md:gap-4 text-sm md:text-base">
          <div className="flex items-center gap-2">
            <div className="w-12 h-1.5 bg-green-600 rounded flex-shrink-0"></div>
            <span className="font-medium">Conjonction</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-12 h-1.5 bg-blue-600 rounded flex-shrink-0"></div>
            <span className="font-medium">Sextile</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-12 h-1.5 bg-red-600 rounded flex-shrink-0"></div>
            <span className="font-medium">Carré</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-12 h-1.5 bg-green-500 rounded flex-shrink-0"></div>
            <span className="font-medium">Trigone</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-12 h-1.5 bg-red-500 rounded flex-shrink-0"></div>
            <span className="font-medium">Opposition</span>
          </div>
        </div>
      </div>

      <div className="w-full mt-2 p-4 md:p-5 bg-white rounded-xl shadow-md border border-slate-200">
        <h3 className="text-base md:text-lg font-bold text-slate-800 mb-3">Légende des signes</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4 text-sm md:text-base">
          {zodiacSigns.map((sign) => (
            <div key={sign.name} className="flex items-center gap-2">
              <span className="text-2xl flex-shrink-0">{sign.emoji}</span>
              <span className="font-medium">{sign.name}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="w-full mt-2 p-4 md:p-5 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl shadow-md border border-blue-200">
        <h3 className="text-base md:text-lg font-bold text-slate-800 mb-2">Partager cette carte</h3>
        <div className="flex items-center gap-3">
          <input
            type="text"
            value={window.location.href}
            readOnly
            className="flex-1 px-4 py-2 bg-white rounded-lg border border-slate-300 text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={() => {
              navigator.clipboard.writeText(window.location.href);
              alert('Lien copié !');
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap"
          >
            Copier
          </button>
        </div>
      </div>

      {selectedPlanet && (
        <DetailModal
          planet={selectedPlanet}
          position={selectedPlanet === 'ascendant' ? {
            longitude: houses[0]?.cusp || 0,
            latitude: 0,
            distance: 0,
            sign: houses[0]?.sign || '',
            signDegree: houses[0]?.signDegree || 0,
            house: 1,
          } : planetPositions[selectedPlanet]}
          onClose={() => setSelectedPlanet(null)}
        />
      )}
    </div>
  );
}
