export const PLANET_INFO: Record<string, { name: string; description: string; keywords: string }> = {
  sun: {
    name: 'Soleil',
    description: 'Votre essence profonde, votre identité et votre volonté. Le Soleil représente qui vous êtes vraiment, votre énergie vitale et votre chemin de vie.',
    keywords: 'Identité • Ego • Volonté • Créativité • Vitalité'
  },
  moon: {
    name: 'Lune',
    description: 'Vos émotions, votre monde intérieur et vos besoins affectifs. La Lune révèle comment vous réagissez émotionnellement et ce qui vous sécurise.',
    keywords: 'Émotions • Intuition • Besoins • Mémoire • Famille'
  },
  mercury: {
    name: 'Mercure',
    description: 'Votre façon de penser, communiquer et apprendre. Mercure gouverne votre intelligence, vos échanges et votre curiosité intellectuelle.',
    keywords: 'Communication • Intellect • Apprentissage • Échanges'
  },
  venus: {
    name: 'Vénus',
    description: 'Votre manière d\'aimer, vos valeurs et votre sens esthétique. Vénus dévoile ce qui vous attire, vos plaisirs et vos relations affectives.',
    keywords: 'Amour • Beauté • Plaisirs • Relations • Valeurs'
  },
  mars: {
    name: 'Mars',
    description: 'Votre énergie d\'action, votre courage et vos désirs. Mars montre comment vous agissez, vous affirmez et poursuivez vos objectifs.',
    keywords: 'Action • Courage • Désir • Énergie • Combativité'
  },
  jupiter: {
    name: 'Jupiter',
    description: 'Votre expansion, votre chance et votre sagesse. Jupiter représente vos opportunités, votre optimisme et votre quête de sens.',
    keywords: 'Expansion • Chance • Sagesse • Abondance • Philosophie'
  },
  saturn: {
    name: 'Saturne',
    description: 'Votre structure, vos responsabilités et vos leçons de vie. Saturne enseigne la discipline, la patience et la maturité.',
    keywords: 'Discipline • Responsabilité • Temps • Structure • Sagesse'
  },
  uranus: {
    name: 'Uranus',
    description: 'Votre originalité, vos innovations et votre liberté. Uranus impulse le changement, l\'indépendance et l\'avant-gardisme.',
    keywords: 'Innovation • Liberté • Originalité • Changement • Révolution'
  },
  neptune: {
    name: 'Neptune',
    description: 'Votre imagination, votre spiritualité et vos rêves. Neptune connecte à l\'invisible, l\'inspiration et la transcendance.',
    keywords: 'Intuition • Spiritualité • Rêves • Inspiration • Mystère'
  },
  pluto: {
    name: 'Pluton',
    description: 'Votre transformation, votre pouvoir et votre renaissance. Pluton révèle vos profondeurs et votre capacité de métamorphose.',
    keywords: 'Transformation • Pouvoir • Régénération • Profondeur'
  },
  ascendant: {
    name: 'Ascendant',
    description: 'Votre masque social, votre apparence et votre façon de vous présenter au monde. L\'Ascendant est la porte d\'entrée de votre thème natal.',
    keywords: 'Apparence • Personnalité • Premier contact • Spontanéité'
  }
};

export const SIGN_DETAILED: Record<string, { element: string; quality: string; ruler: string; description: string }> = {
  'Bélier': {
    element: 'Feu',
    quality: 'Cardinal',
    ruler: 'Mars',
    description: 'Pionnier intrépide, le Bélier fonce tête baissée vers ses objectifs. Initiative, courage et spontanéité caractérisent ce signe qui aime être le premier.'
  },
  'Taureau': {
    element: 'Terre',
    quality: 'Fixe',
    ruler: 'Vénus',
    description: 'Stable et sensuel, le Taureau recherche la sécurité matérielle et les plaisirs concrets. Patient et déterminé, il construit sur le long terme.'
  },
  'Gémeaux': {
    element: 'Air',
    quality: 'Mutable',
    ruler: 'Mercure',
    description: 'Curieux et communicatif, les Gémeaux papillonnent d\'une idée à l\'autre. Polyvalents et sociables, ils excellent dans l\'échange et l\'adaptation.'
  },
  'Cancer': {
    element: 'Eau',
    quality: 'Cardinal',
    ruler: 'Lune',
    description: 'Sensible et protecteur, le Cancer est profondément lié à ses émotions et sa famille. Intuitif et empathique, il crée un cocon sécurisant.'
  },
  'Lion': {
    element: 'Feu',
    quality: 'Fixe',
    ruler: 'Soleil',
    description: 'Généreux et charismatique, le Lion rayonne naturellement. Créatif et fier, il aime être au centre de l\'attention et inspirer les autres.'
  },
  'Vierge': {
    element: 'Terre',
    quality: 'Mutable',
    ruler: 'Mercure',
    description: 'Analytique et perfectionniste, la Vierge excelle dans les détails et l\'organisation. Pratique et serviable, elle améliore tout ce qu\'elle touche.'
  },
  'Balance': {
    element: 'Air',
    quality: 'Cardinal',
    ruler: 'Vénus',
    description: 'Harmonieux et diplomate, la Balance recherche l\'équilibre et la beauté. Sociable et juste, elle excelle dans les relations et la médiation.'
  },
  'Scorpion': {
    element: 'Eau',
    quality: 'Fixe',
    ruler: 'Pluton',
    description: 'Intense et passionné, le Scorpion plonge dans les profondeurs de l\'existence. Magnétique et transformateur, il ne fait rien à moitié.'
  },
  'Sagittaire': {
    element: 'Feu',
    quality: 'Mutable',
    ruler: 'Jupiter',
    description: 'Optimiste et aventurier, le Sagittaire aspire à l\'expansion et à la découverte. Philosophe et libre, il recherche le sens de la vie.'
  },
  'Capricorne': {
    element: 'Terre',
    quality: 'Cardinal',
    ruler: 'Saturne',
    description: 'Ambitieux et discipliné, le Capricorne gravit patiemment la montagne du succès. Responsable et mature, il bâtit avec persévérance.'
  },
  'Verseau': {
    element: 'Air',
    quality: 'Fixe',
    ruler: 'Uranus',
    description: 'Original et visionnaire, le Verseau incarne l\'innovation et la liberté. Humaniste et indépendant, il pense différemment des autres.'
  },
  'Poissons': {
    element: 'Eau',
    quality: 'Mutable',
    ruler: 'Neptune',
    description: 'Intuitif et compassionnel, les Poissons nagent entre deux mondes. Artistique et empathique, ce signe se connecte au subtil et à l\'universel.'
  }
};

export const HOUSE_MEANINGS: Record<number, { name: string; theme: string; description: string }> = {
  1: {
    name: 'Maison de l\'Identité',
    theme: 'Personnalité et apparence',
    description: 'Votre façon d\'être et de vous présenter au monde. L\'Ascendant, porte d\'entrée de votre thème, définit votre masque social et votre énergie spontanée.'
  },
  2: {
    name: 'Maison des Ressources',
    theme: 'Argent et valeurs',
    description: 'Vos possessions matérielles, vos talents et ce que vous valorisez. Cette maison parle de votre rapport à l\'argent et à votre sécurité matérielle.'
  },
  3: {
    name: 'Maison de la Communication',
    theme: 'Échanges et apprentissage',
    description: 'Votre communication, vos apprentissages et votre entourage proche. Frères, sœurs, voisins et déplacements courts y sont représentés.'
  },
  4: {
    name: 'Maison des Racines',
    theme: 'Famille et foyer',
    description: 'Vos origines, votre famille et votre foyer. Le Fond du Ciel révèle vos racines profondes et ce qui vous ancre émotionnellement.'
  },
  5: {
    name: 'Maison de la Créativité',
    theme: 'Plaisirs et créations',
    description: 'Votre créativité, vos loisirs, vos enfants et vos amours. Cette maison exprime votre joie de vivre et ce qui vous fait vibrer.'
  },
  6: {
    name: 'Maison du Quotidien',
    theme: 'Travail et santé',
    description: 'Votre routine, votre travail quotidien et votre santé. Elle indique comment vous gérez les obligations et prenez soin de vous.'
  },
  7: {
    name: 'Maison des Associations',
    theme: 'Relations et partenariats',
    description: 'Vos relations de couple, vos associations et vos contrats. Le Descendant montre ce que vous recherchez chez l\'autre.'
  },
  8: {
    name: 'Maison des Transformations',
    theme: 'Mort et renaissance',
    description: 'Les transformations profondes, la sexualité et les ressources partagées. Mystères, crises et régénérations y prennent place.'
  },
  9: {
    name: 'Maison de l\'Expansion',
    theme: 'Philosophie et voyages',
    description: 'Votre quête de sens, vos voyages lointains et vos études supérieures. C\'est la maison de la sagesse et de l\'exploration.'
  },
  10: {
    name: 'Maison de la Vocation',
    theme: 'Carrière et réputation',
    description: 'Votre carrière, votre statut social et votre accomplissement public. Le Milieu du Ciel indique votre destinée professionnelle.'
  },
  11: {
    name: 'Maison des Projets',
    theme: 'Amis et idéaux',
    description: 'Vos amitiés, vos projets collectifs et vos idéaux. Cette maison parle de vos rêves et de votre contribution au groupe.'
  },
  12: {
    name: 'Maison de l\'Invisible',
    theme: 'Spiritualité et inconscient',
    description: 'Votre spiritualité, votre inconscient et ce qui est caché. Épreuves karmiques, retraites et connexion au divin s\'y manifestent.'
  }
};

export const ASPECT_MEANINGS: Record<string, { nature: string; description: string; interpretation: string }> = {
  'Conjonction': {
    nature: 'Fusion',
    description: 'Deux planètes unies (0°) fusionnent leurs énergies.',
    interpretation: 'Les qualités des deux planètes se mélangent intensément, créant une force puissante qui peut être constructive ou difficile selon les planètes impliquées.'
  },
  'Sextile': {
    nature: 'Opportunité',
    description: 'Deux planètes en harmonie facile (60°).',
    interpretation: 'Cet aspect offre des opportunités naturelles et des facilités. Les énergies coopèrent sans effort, créant des possibilités qu\'il faut saisir.'
  },
  'Carré': {
    nature: 'Défi',
    description: 'Deux planètes en tension créative (90°).',
    interpretation: 'Cet aspect génère des tensions et des défis qui poussent à l\'action. La friction créée est inconfortable mais stimulante et mène à la croissance.'
  },
  'Trigone': {
    nature: 'Harmonie',
    description: 'Deux planètes en harmonie fluide (120°).',
    interpretation: 'Aspect le plus favorable, le trigone indique des talents naturels et une aisance instinctive. Les énergies circulent librement et harmonieusement.'
  },
  'Opposition': {
    nature: 'Polarité',
    description: 'Deux planètes face à face (180°) créant une tension.',
    interpretation: 'Cet aspect demande de trouver l\'équilibre entre deux forces opposées. La conscience de cette dualité permet l\'intégration et la complémentarité.'
  }
};

export function getPlanetInSignInterpretation(planet: string, sign: string): string {
  const interpretations: Record<string, Record<string, string>> = {
    sun: {
      'Bélier': 'Vous êtes un leader naturel, courageux et toujours prêt à foncer. L\'action directe vous caractérise.',
      'Taureau': 'Vous recherchez la stabilité et les plaisirs concrets. Votre détermination est légendaire.',
      'Gémeaux': 'Votre curiosité intellectuelle est insatiable. Vous excellez dans la communication et l\'adaptabilité.',
      'Cancer': 'Vos émotions guident vos actions. Famille et sécurité affective sont essentielles pour vous.',
      'Lion': 'Vous rayonnez naturellement et inspirez votre entourage. La créativité est votre force.',
      'Vierge': 'L\'analyse et le perfectionnisme vous animent. Vous excellez dans les détails et le service.',
      'Balance': 'L\'harmonie et les relations sont au cœur de votre être. Vous êtes naturellement diplomate.',
      'Scorpion': 'Votre intensité et votre passion sont remarquables. Vous explorez les profondeurs de l\'existence.',
      'Sagittaire': 'L\'aventure et la quête de sens vous animent. Votre optimisme est contagieux.',
      'Capricorne': 'L\'ambition et la discipline vous caractérisent. Vous construisez patiemment votre succès.',
      'Verseau': 'Votre originalité et votre indépendance vous définissent. Vous êtes un visionnaire.',
      'Poissons': 'Votre intuition et votre compassion sont exceptionnelles. Vous êtes connecté au monde subtil.'
    },
    moon: {
      'Bélier': 'Vos réactions émotionnelles sont vives et spontanées. Vous avez besoin d\'action pour vous sentir bien.',
      'Taureau': 'Vous recherchez la stabilité émotionnelle et le confort. Les plaisirs sensoriels vous apaisent.',
      'Gémeaux': 'Votre monde intérieur est varié et mobile. La communication nourrit votre bien-être émotionnel.',
      'Cancer': 'Hypersensible, vous avez un besoin profond de sécurité et d\'appartenance. L\'intuition vous guide.',
      'Lion': 'Vous exprimez vos émotions avec chaleur et générosité. Être apprécié nourrit votre âme.',
      'Vierge': 'Vous analysez vos sentiments et cherchez la perfection émotionnelle. Le service vous apaise.',
      'Balance': 'L\'harmonie relationnelle est vitale pour votre équilibre. Vous évitez les conflits émotionnels.',
      'Scorpion': 'Vos émotions sont d\'une intensité rare. Vous ressentez tout profondément et magnétiquement.',
      'Sagittaire': 'Votre optimisme naturel colore vos émotions. La liberté émotionnelle est essentielle.',
      'Capricorne': 'Vous maîtrisez vos émotions avec maturité. La réserve émotionnelle vous protège.',
      'Verseau': 'Votre indépendance émotionnelle est importante. Vous rationalisez vos sentiments.',
      'Poissons': 'Ultra empathique, vous absorbez les émotions ambiantes. Votre sensibilité est osmotique.'
    },
    mercury: {
      'Bélier': 'Votre pensée est rapide et directe. Vous communiquez sans détour, avec franchise.',
      'Taureau': 'Vous réfléchissez posément et concrètement. Vos idées sont pratiques et stables.',
      'Gémeaux': 'Votre intelligence est vive et polyvalente. La communication est votre superpouvoir.',
      'Cancer': 'Votre pensée est intuitive et émotionnelle. La mémoire est votre force.',
      'Lion': 'Vous vous exprimez avec confiance et créativité. Votre communication est charismatique.',
      'Vierge': 'Votre esprit analytique excelle dans les détails. Organisation et précision vous caractérisent.',
      'Balance': 'Vous pesez le pour et le contre, recherchant l\'équité. Votre communication est diplomate.',
      'Scorpion': 'Votre pensée est profonde et investigatrice. Vous percez les mystères facilement.',
      'Sagittaire': 'Votre esprit philosophique embrasse les grandes idées. L\'optimisme teinte vos pensées.',
      'Capricorne': 'Votre réflexion est structurée et pragmatique. Vous pensez stratégiquement.',
      'Verseau': 'Votre pensée est originale et avant-gardiste. L\'innovation intellectuelle vous anime.',
      'Poissons': 'Votre imagination est fertile. L\'intuition guide votre intelligence.'
    }
  };

  return interpretations[planet]?.[sign] || `${PLANET_INFO[planet]?.name} en ${sign} colore votre personnalité de manière unique.`;
}

export function getAspectInterpretation(planet1: string, planet2: string, aspectType: string): string {
  const p1Name = PLANET_INFO[planet1]?.name || planet1;
  const p2Name = PLANET_INFO[planet2]?.name || planet2;

  const key = [planet1, planet2].sort().join('-');

  const aspectInterpretations: Record<string, Record<string, string>> = {
    'moon-sun': {
      'Conjonction': 'Votre conscience et vos émotions sont parfaitement alignées. Vous êtes authentique, exprimant naturellement ce que vous ressentez. Cette unité intérieure crée une personnalité cohérente et intègre.',
      'Trigone': 'Harmonie naturelle entre votre être profond et votre vie émotionnelle. Vous vous sentez bien dans votre peau et rayonnez une énergie positive qui attire les autres.',
      'Carré': 'Tension entre ce que vous voulez être et ce que vous ressentez. Cette friction vous pousse à évoluer mais demande un effort conscient pour réconcilier votre tête et votre cœur.',
      'Opposition': 'Votre conscience et vos émotions semblent tirer dans des directions opposées. L\'objectif est de les honorer toutes les deux et de trouver un équilibre dynamique.',
      'Sextile': 'Facilité à exprimer vos émotions de manière constructive. Vous savez instinctivement comment nourrir votre bien-être émotionnel.'
    },
    'mercury-sun': {
      'Conjonction': 'Votre identité et votre intellect fusionnent. Vous êtes brillant et communiquez avec assurance. Attention toutefois à garder une certaine objectivité sur vous-même.',
      'Trigone': 'Votre pensée reflète naturellement qui vous êtes. Communication fluide, créativité intellectuelle et capacité à vous exprimer avec clarté.',
      'Carré': 'Tension entre votre ego et votre raison. Vous pouvez avoir du mal à rester objectif ou tendre vers l\'hyper-rationalisation. Cette friction stimule votre intelligence.',
      'Opposition': 'Votre pensée peut critiquer votre être ou inversement. L\'équilibre se trouve en intégrant raison et intuition, mental et cœur.',
      'Sextile': 'Facilité à communiquer qui vous êtes. Votre expression correspond à votre essence, créant une communication authentique et efficace.'
    },
    'mercury-moon': {
      'Conjonction': 'Vos pensées et émotions sont intimement liées. Vous exprimez facilement vos sentiments mais pouvez aussi être submergé émotionnellement dans vos réflexions.',
      'Trigone': 'Intelligence émotionnelle naturelle. Vous comprenez intuitivement les autres et savez communiquer avec sensibilité et empathie.',
      'Carré': 'Conflit entre raison et émotion. Vos sentiments brouillent parfois votre jugement, mais cette tension développe une compréhension profonde de la psychologie.',
      'Opposition': 'Votre tête et votre cœur dialoguent constamment. L\'enjeu est d\'écouter les deux sans les laisser se dominer mutuellement.',
      'Sextile': 'Vous communiquez vos besoins émotionnels avec aisance. Bonne mémoire émotionnelle et capacité à comprendre les subtilités relationnelles.'
    },
    'mars-sun': {
      'Conjonction': 'Énergie vitale débordante et volonté d\'action puissante. Vous êtes un guerrier naturel, courageux et déterminé. Apprenez à canaliser cette force.',
      'Trigone': 'Action et identité s\'harmonisent parfaitement. Vous savez qui vous êtes et agissez en conséquence. Leadership naturel et confiance en soi.',
      'Carré': 'Conflit intérieur entre désir d\'action et sens de soi. Cette tension crée une dynamique puissante mais peut générer frustration et impatience.',
      'Opposition': 'Tiraillement entre affirmation de soi et action impulsive. Apprendre à agir selon vos valeurs profondes plutôt que par réaction.',
      'Sextile': 'Capacité naturelle à passer à l\'action de manière constructive. Votre énergie soutient vos objectifs personnels efficacement.'
    },
    'mars-moon': {
      'Conjonction': 'Vos émotions sont intenses et vous réagissez rapidement. Passion, courage émotionnel, mais aussi impulsivité dans vos réactions affectives.',
      'Trigone': 'Force émotionnelle et capacité d\'action harmonieuses. Vous défendez naturellement ce qui compte pour vous sur le plan émotionnel.',
      'Carré': 'Tensions émotionnelles qui vous poussent à l\'action. Colère et frustration peuvent surgir rapidement, mais cette énergie peut être transformée.',
      'Opposition': 'Combat entre besoins émotionnels et désirs d\'action. L\'équilibre demande de respecter vos émotions tout en agissant de manière constructive.',
      'Sextile': 'Énergie émotionnelle bien canalisée. Vous savez agir pour protéger et nourrir ce qui vous tient à cœur.'
    },
    'mercury-venus': {
      'Conjonction': 'Charme naturel dans la communication. Vous savez choisir les mots justes et apprécier la beauté des idées. Diplomatie et goût artistique.',
      'Trigone': 'Communication harmonieuse et agréable. Vous créez facilement des connexions et exprimez l\'affection avec élégance et naturel.',
      'Carré': 'Tension entre pensée et plaisir. Difficulté à choisir entre raison et sentiment, mais cette friction affine votre discernement.',
      'Opposition': 'Votre tête dit une chose, votre cœur une autre. L\'art consiste à honorer à la fois la logique et l\'amour.',
      'Sextile': 'Facilité à exprimer l\'affection verbalement. Communication chaleureuse et capacité à créer de l\'harmonie par les mots.'
    },
    'mars-venus': {
      'Conjonction': 'Passion intense dans l\'amour et l\'art. Désir et affection fusionnent, créant une nature magnétique et créative. Séduction naturelle.',
      'Trigone': 'Harmonie entre désir et affection. Vous attirez naturellement ce que vous aimez et aimez ce que vous poursuivez. Charisme et créativité.',
      'Carré': 'Conflit entre désir et amour, passion et tendresse. Cette tension crée une intensité dans vos relations et stimule votre créativité.',
      'Opposition': 'Attraction et répulsion alternent. L\'enjeu est d\'intégrer passion et affection dans une expression équilibrée de l\'amour.',
      'Sextile': 'Capacité naturelle à attirer et créer. Votre action soutient vos valeurs et vous poursuivez vos désirs de manière harmonieuse.'
    },
    'jupiter-sun': {
      'Conjonction': 'Optimisme naturel et foi en vous-même. Vous voyez grand et inspirez confiance. Générosité et quête de sens caractérisent votre être.',
      'Trigone': 'Chance et expansion naturelles. Les opportunités viennent facilement car vous rayonnez positivement. Sagesse et croissance harmonieuse.',
      'Carré': 'Tension entre expansion et identité. Tendance à l\'excès ou au manque de mesure, mais cette énergie pousse à grandir constamment.',
      'Opposition': 'Tiraillement entre modestie et grandeur. L\'équilibre se trouve en restant authentique tout en embrassant vos possibilités.',
      'Sextile': 'Opportunités de croissance personnelle se présentent facilement. Votre optimisme soutient naturellement votre développement.'
    },
    'jupiter-moon': {
      'Conjonction': 'Générosité émotionnelle et foi profonde. Votre cœur est grand et vous avez besoin d\'expansion émotionnelle. Optimisme et empathie.',
      'Trigone': 'Bien-être émotionnel naturel. Vous savez instinctivement comment nourrir votre âme et celle des autres. Protection et chance émotionnelles.',
      'Carré': 'Excès émotionnels possibles. Tendance à trop donner ou trop attendre émotionnellement, mais cette générosité vous fait grandir.',
      'Opposition': 'Balance entre besoins émotionnels et expansion. L\'enjeu est de croître sans se perdre, de donner sans s\'oublier.',
      'Sextile': 'Facilité à trouver joie et sens dans vos émotions. Votre optimisme nourrit naturellement votre bien-être intérieur.'
    },
    'jupiter-saturn': {
      'Conjonction': 'Équilibre unique entre expansion et contraction. Vous savez croître avec sagesse, combinant optimisme et réalisme de manière constructive.',
      'Trigone': 'Chance structurée et discipline optimiste. Vous manifestez vos rêves avec patience et méthode. Succès durable et mérité.',
      'Carré': 'Conflit entre croissance et limitation. Cette tension vous enseigne la persévérance et la sagesse à travers les hauts et les bas.',
      'Opposition': 'Oscillation entre foi et peur, expansion et retrait. L\'intégration de ces deux forces crée une sagesse profonde.',
      'Sextile': 'Opportunités de construire solidement. Votre optimisme trouve une structure et vos efforts sont récompensés justement.'
    },
    'mercury-saturn': {
      'Conjonction': 'Pensée sérieuse et structurée. Concentration, profondeur intellectuelle mais parfois tendance au pessimisme. Grande capacité d\'apprentissage méthodique.',
      'Trigone': 'Pensée claire et organisée. Vous structurez naturellement vos idées et communiquez avec autorité et sagesse.',
      'Carré': 'Blocages mentaux ou pensées négatives possibles. Cette tension développe rigueur et profondeur intellectuelle à travers l\'effort.',
      'Opposition': 'Tension entre spontanéité mentale et structure. L\'équilibre crée une pensée à la fois libre et disciplinée.',
      'Sextile': 'Facilité à organiser vos pensées. Communication claire, apprentissage méthodique et capacité à enseigner.'
    },
    'moon-venus': {
      'Conjonction': 'Douceur émotionnelle naturelle. Vous recherchez harmonie et beauté dans vos relations. Affection et sensibilité artistique.',
      'Trigone': 'Grâce émotionnelle et capacité d\'aimer facilement. Vous attirez l\'affection et créez naturellement de la beauté autour de vous.',
      'Carré': 'Tension entre besoins émotionnels et désirs relationnels. Cette friction affine votre compréhension de l\'amour et de l\'harmonie.',
      'Opposition': 'Balance entre donner et recevoir l\'amour. L\'enjeu est d\'honorer vos besoins tout en restant ouvert aux autres.',
      'Sextile': 'Facilité à exprimer affection et créer harmonie. Vous savez naturellement embellir votre vie émotionnelle.'
    },
    'saturn-sun': {
      'Conjonction': 'Sens aigu des responsabilités. Vous vous prenez au sérieux et construisez votre identité avec patience. Maturité précoce.',
      'Trigone': 'Structure et identité s\'harmonisent. Vous incarnez naturellement sagesse et autorité. Succès mérité par le travail.',
      'Carré': 'Épreuves de confiance en soi. Cette tension construit une force intérieure authentique à travers la persévérance.',
      'Opposition': 'Conflit entre spontanéité et responsabilité. L\'équilibre crée une identité à la fois libre et mature.',
      'Sextile': 'Capacité naturelle à vous structurer. Vos efforts construisent solidement votre identité et votre confiance.'
    },
    'ascendant-sun': {
      'Conjonction': 'Votre essence profonde et votre apparence fusionnent. Vous êtes authentique et ce que vous paraissez correspond à ce que vous êtes. Rayonnement naturel.',
      'Trigone': 'Harmonie entre votre être intérieur et votre masque social. Vous vous présentez naturellement de façon authentique et attrayante.',
      'Carré': 'Tension entre qui vous êtes et comment vous apparaissez. Cette friction vous pousse à développer une image plus alignée avec votre essence.',
      'Opposition': 'Contraste marqué entre votre identité profonde et votre personnalité sociale. L\'intégration crée une personnalité riche et nuancée.',
      'Sextile': 'Facilité à exprimer votre essence à travers votre apparence. Vous savez naturellement vous présenter de manière favorable.'
    },
    'ascendant-moon': {
      'Conjonction': 'Vos émotions sont visibles sur votre visage. Vous êtes spontanément émotif et les autres perçoivent facilement vos sentiments. Authenticité émotionnelle.',
      'Trigone': 'Votre sensibilité transparaît harmonieusement dans votre comportement. Vous créez une première impression chaleureuse et accueillante.',
      'Carré': 'Conflit entre vos besoins émotionnels et votre image sociale. Cette tension vous apprend à équilibrer expression et protection émotionnelles.',
      'Opposition': 'Vos émotions privées contrastent avec votre façade publique. L\'enjeu est d\'intégrer vie intérieure et expression extérieure.',
      'Sextile': 'Facilité à exprimer vos émotions de manière appropriée socialement. Vous créez naturellement un climat émotionnel positif.'
    },
    'ascendant-mercury': {
      'Conjonction': 'Votre intelligence et votre communication sont immédiatement perceptibles. Vous êtes identifié comme quelqu\'un de curieux et communicatif.',
      'Trigone': 'Votre façon de penser s\'exprime naturellement dans votre comportement. Communication fluide et apparence intelligente.',
      'Carré': 'Tension entre votre mental et votre image. Difficulté parfois à communiquer comme vous le souhaitez, ce qui affine votre expression.',
      'Opposition': 'Votre façon de penser peut contredire votre apparence. L\'équilibre crée une communication authentique et nuancée.',
      'Sextile': 'Facilité à communiquer votre personnalité. Vous savez instinctivement adapter votre message à votre audience.'
    },
    'ascendant-venus': {
      'Conjonction': 'Charme naturel et beauté évidente. Vous êtes immédiatement perçu comme attirant, agréable et harmonieux. Magnétisme social.',
      'Trigone': 'Grâce et élégance naturelles dans votre présentation. Vous attirez facilement la sympathie et créez de belles premières impressions.',
      'Carré': 'Conflit entre vos valeurs et votre image. Cette tension vous pousse à affiner votre style et votre façon de plaire.',
      'Opposition': 'Contraste entre ce que vous aimez et ce que vous montrez. L\'intégration crée une authenticité charmante.',
      'Sextile': 'Facilité à vous présenter de manière attrayante. Vous savez naturellement mettre en valeur vos qualités esthétiques.'
    },
    'ascendant-mars': {
      'Conjonction': 'Énergie visible et dynamisme évident. Vous êtes perçu comme courageux, direct et combatif. Forte présence physique.',
      'Trigone': 'Votre énergie s\'exprime harmonieusement dans vos actions. Leadership naturel et capacité à inspirer l\'action chez les autres.',
      'Carré': 'Tension entre votre agressivité et votre image. Cette friction développe une assertivité plus raffinée et contrôlée.',
      'Opposition': 'Contraste entre votre désir d\'action et votre comportement social. L\'équilibre crée une affirmation de soi équilibrée.',
      'Sextile': 'Facilité à agir de manière appropriée socialement. Votre énergie soutient naturellement votre présentation.'
    },
    'ascendant-jupiter': {
      'Conjonction': 'Optimisme et générosité évidents. Vous êtes perçu comme chanceux, sage et inspirant. Présence expansive et positive.',
      'Trigone': 'Votre foi et votre optimisme transparaissent naturellement. Vous créez des opportunités par votre seule présence positive.',
      'Carré': 'Excès possibles dans votre présentation. Tendance à l\'exagération ou au manque de mesure, mais cette énergie attire la chance.',
      'Opposition': 'Tension entre croissance personnelle et image sociale. L\'équilibre crée une expansion authentique et mesurée.',
      'Sextile': 'Facilité à attirer les opportunités par votre attitude positive. Votre optimisme enrichit votre présence sociale.'
    },
    'ascendant-saturn': {
      'Conjonction': 'Sérieux et maturité évidents. Vous êtes perçu comme responsable, discipliné et digne de confiance. Autorité naturelle.',
      'Trigone': 'Structure et image s\'harmonisent. Vous incarnez naturellement sagesse et crédibilité. Respect et confiance vous suivent.',
      'Carré': 'Blocages dans votre expression sociale. Cette tension construit une présence authentique à travers la persévérance.',
      'Opposition': 'Conflit entre spontanéité et contrôle de votre image. L\'intégration crée une présence à la fois libre et mature.',
      'Sextile': 'Facilité à vous présenter de manière professionnelle. Votre sérieux soutient naturellement votre crédibilité sociale.'
    },
    'ascendant-uranus': {
      'Conjonction': 'Originalité évidente et indépendance marquée. Vous êtes perçu comme unique, innovant et parfois excentrique. Magnétisme électrique.',
      'Trigone': 'Votre individualité s\'exprime harmonieusement. Vous êtes authentiquement vous-même et cela attire les autres naturellement.',
      'Carré': 'Comportement imprévisible ou difficultés d\'adaptation sociale. Cette tension développe une authenticité courageuse.',
      'Opposition': 'Tiraillement entre conformité et rébellion. L\'équilibre crée une individualité respectueuse mais affirmée.',
      'Sextile': 'Facilité à exprimer votre originalité de manière acceptable. Votre différence devient un atout social.'
    },
    'ascendant-neptune': {
      'Conjonction': 'Aura mystérieuse et sensibilité évidente. Vous êtes perçu comme inspirant, artistique ou insaisissable. Présence éthérée.',
      'Trigone': 'Imagination et spiritualité transparaissent harmonieusement. Vous inspirez naturellement et attirez par votre douceur.',
      'Carré': 'Confusion possible sur votre identité ou image floue. Cette tension développe une authenticité spirituelle profonde.',
      'Opposition': 'Contraste entre idéal et réalité de votre image. L\'intégration crée une présence à la fois inspirante et authentique.',
      'Sextile': 'Facilité à exprimer votre sensibilité artistique. Votre créativité enrichit naturellement votre présentation sociale.'
    },
    'ascendant-pluto': {
      'Conjonction': 'Intensité et magnétisme puissants. Vous êtes perçu comme transformateur, intense et mystérieux. Présence magnétique irrésistible.',
      'Trigone': 'Votre pouvoir personnel s\'exprime harmonieusement. Vous transformez naturellement votre environnement par votre seule présence.',
      'Carré': 'Luttes de pouvoir liées à votre image. Cette tension développe une présence authentiquement puissante à travers la transformation.',
      'Opposition': 'Conflit entre votre profondeur et votre surface. L\'intégration crée une authenticité magnétique et transformatrice.',
      'Sextile': 'Facilité à exprimer votre intensité de manière appropriée. Votre profondeur enrichit naturellement vos interactions.'
    }
  };

  const interpretation = aspectInterpretations[key]?.[aspectType];

  if (interpretation) {
    return interpretation;
  }

  const genericInterpretations: Record<string, string> = {
    'Conjonction': `L'énergie de ${p1Name} et celle de ${p2Name} fusionnent complètement, créant une force unique qui amplifie les qualités des deux planètes.`,
    'Trigone': `${p1Name} et ${p2Name} travaillent ensemble harmonieusement, vous offrant un talent naturel dans les domaines qu'elles représentent.`,
    'Carré': `La tension entre ${p1Name} et ${p2Name} crée des défis stimulants qui, bien qu'inconfortables, vous poussent à grandir et à évoluer.`,
    'Opposition': `${p1Name} et ${p2Name} vous tirent dans des directions opposées. L'équilibre entre ces deux forces est votre chemin de croissance.`,
    'Sextile': `${p1Name} et ${p2Name} créent des opportunités faciles. Leurs énergies se soutiennent mutuellement de manière constructive.`
  };

  return genericInterpretations[aspectType] || 'Cet aspect crée une dynamique unique dans votre thème.';
}
